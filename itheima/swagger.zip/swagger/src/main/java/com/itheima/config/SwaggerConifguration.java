package com.itheima.config;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;

/**
 * Created by zhanglin on 2021/7/21.
 */
@Configuration
public class SwaggerConifguration {

    /**
     * 创建Docket类型对象，并使用spring容器管理
     * Docket是Swagger中的全局配置对象
     * @return
     */
    @Bean
    public Docket docket(){

        Docket docket = new Docket(DocumentationType.SWAGGER_2);
        ApiInfo apiInfo =
                new ApiInfoBuilder().contact(new Contact(
                        //配置swagger文档主题内容
                        "OSS-ZhangLin的Swagger开发文档",//文档发布者名称
                        "http://www.bjsxt.com",             //文档发布者的网站地址，一般是企业网站
                        "admin@zhanglin.com")               //文档发布者的邮箱
                ).title("Swagger框架学习帮助文档")
                        .description("")
                        .build();

        docket.apiInfo(apiInfo);


        return docket;

    }


}
